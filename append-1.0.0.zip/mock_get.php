<?php
$_GET['code'] = 'AGISL/EHS/FA/017/W13122X4HP3KN';
?>
