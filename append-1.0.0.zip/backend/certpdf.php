<?php
session_start();

// require_once 'phpqrcode/qrlib.php';

// function generateQRCode($data, $filename = null, $size = 6)
// {
//     // If no filename is given, generate unique file
//     if ($filename === null) {
//         $filename = 'qrcodes/' . md5($data . time()) . '.png';
//     }

//     // Create folder if it doesn't exist
//     if (!file_exists('qrcodes')) {
//         mkdir('qrcodes', 0777, true);
//     }

//     // Generate QR Code
//     QRcode::png(
//         $data,
//         $filename,
//         QR_ECLEVEL_H, // High error correction
//         $size,
//         2
//     );

//     return $filename;
// }

const ENC_KEY = 'AGISL_CERT_SECRET_KEY'; // Secret key for encryption
const ENC_METHOD = 'AES-128-ECB'; // Encryption method

function encryptCode($code)
{
    return urlencode(base64_encode(openssl_encrypt($code, ENC_METHOD, ENC_KEY)));
}

function decryptCode($encrypted)
{
    $decoded = openssl_decrypt(base64_decode(urldecode($encrypted)), ENC_METHOD, ENC_KEY);
    return $decoded !== false ? $decoded : $encrypted; // Fallback to raw if decryption fails
}

// Prioritize GET parameter over Session
$cert_code = null;

// Check for session expiration (40 minutes)
if (isset($_SESSION['view_cert_timestamp']) && (time() - $_SESSION['view_cert_timestamp'] > 40 * 60)) {
    unset($_SESSION['view_cert_code']);
    unset($_SESSION['view_cert_timestamp']);
}

if (isset($_GET['code'])) {
    // Came via encrypted URL (e.g., from QR code or redirect after registration)
    $cert_code = decryptCode($_GET['code']);
    // Refresh session timestamp on valid URL access
    if ($cert_code) {
        $_SESSION['view_cert_code'] = $cert_code;
        $_SESSION['view_cert_timestamp'] = time();
    }
}
else {
    // Direct access without a code — always clear session and prompt
    unset($_SESSION['view_cert_code']);
    unset($_SESSION['view_cert_timestamp']);
    $cert_code = null;
}

$dbFile = __DIR__ . '/data.db';
$show_prompt = false;

// Initialize variables with defaults
$name = "---";
$issued = "---";
$validity_period = "---";
$certificate_code = "---";
$expiration_date = "---";
$bg_image = "certificate-bg.jpg";
$qr_code = "";

if (!$cert_code) {
    $show_prompt = true;
}
else {
    try {
        $pdo = new PDO("sqlite:" . $dbFile);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Fetch certificate data
        $stmt = $pdo->prepare("SELECT * FROM certificates WHERE cert_code = :code");
        $stmt->execute([':code' => $cert_code]);
        $cert = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$cert) {
            $show_prompt = true;
            $error_message = "Certificate not found.";
        }
        else {
            // Fetch user data
            $stmt = $pdo->prepare("SELECT * FROM users WHERE cert_code = :code");
            $stmt->execute([':code' => $cert_code]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            // Set variables
            $name = $user ? ($user['firstname'] . ' ' . $user['lastname']) : $cert['owner'];
            $issued = $cert['date_issued'] ?: 'N/A';

            // Validity period calculation (duration)
            $validity_period = '2 years';
            if ($cert['date_issued'] && $cert['expiration_date']) {
                $date1 = new DateTime($cert['date_issued']);
                $date2 = new DateTime($cert['expiration_date']);
                $interval = $date1->diff($date2);

                $parts = [];
                if ($interval->y > 0)
                    $parts[] = $interval->y . ($interval->y > 1 ? ' Years' : ' Year');
                if ($interval->m > 0)
                    $parts[] = $interval->m . ($interval->m > 1 ? ' Months' : ' Month');
                if ($interval->d > 0)
                    $parts[] = $interval->d . ($interval->d > 1 ? ' Days' : ' Day');

                if (!empty($parts)) {
                    $validity_period = implode(', ', $parts);
                }
            }
            $certificate_code = $cert['cert_code'];
            $expiration_date = $cert['expiration_date'] ?: ' 2 years';

            // Background image
            $cert_type = strtolower($cert['cert_type']);
            $bg_image_path = "cert_images/" . $cert_type . ".png";
            $bg_image_missing = false;

            if (file_exists(__DIR__ . '/' . $bg_image_path)) {
                $bg_image = $bg_image_path;
            }
            else {
                $bg_image = "certificate-bg.jpg";
                $bg_image_missing = true;
            }

            // Dynamic URL for QR Code
            $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
            $host = $_SERVER['HTTP_HOST'];
            $current_url = "$protocol://$host" . $_SERVER['PHP_SELF'];
            $verification_link = "$current_url?code=" . encryptCode($certificate_code);

            $qr_code = "https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=" . urlencode($verification_link);
        }
    }
    catch (PDOException $e) {
        $error_message = "Database error: " . $e->getMessage();
        $show_prompt = true;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Certificate - <?php echo $certificate_code; ?></title>

<!-- SweetAlert2 -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<!-- html2pdf.js -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>

<style>
body{
    margin:0;
    padding:0;
    background:#ccc;
}

/* Download Button Style */
.download-btn {
    position: fixed;
    top: 20px;
    right: 20px;
    background: #28a745;
    color: white;
    border: none;
    padding: 10px 20px;
    font-size: 16px;
    font-weight: bold;
    cursor: pointer;
    border-radius: 5px;
    box-shadow: 0 4px 6px rgba(0,0,0,0.1);
    z-index: 1000;
    display: flex;
    align-items: center;
    gap: 8px;
}
.download-btn:hover {
    background: #218838;
}
.download-btn-hidden {
    display: none;
}

/* Certificate Background */
.certificate{
    width:1400px;     /* match your image width */
    height:990px;     /* match your image height */
    margin:auto;
    position:relative;
    background:url('<?php echo $bg_image; ?>') no-repeat center;
    background-size:cover;
    font-family:Arial, sans-serif;
    <?php if ($show_prompt): ?>display:none;<?php
endif; ?>
}

/* Dynamic Name */
.name{
    position:absolute;
    top:440px;        /* adjust if needed */
    left:0;
    width:100%;
    text-align:center;
    font-size:60px;
    font-weight:bold;
    color:#000;
}

/* Certificate Details */
.details{
    position:absolute;
    bottom:200px;
    left:150px;
    font-size:20px;
    color:#333;
    line-height: 1.6;
}

.cert-code-box {
    position:absolute;
    bottom:0.1px;
    left: 100px;
    font-size:18px;
    /* font-weight:bold; */
    color:#555;
    width: 1000px;
}
.validity-period{
position: absolute;
bottom: 27px;
left: 70px;
width: 1000px;
font-size:18px;
}
.issue-date{
    position: absolute;
    bottom: 55px;
    left: 40px;
    width: 1000px;
    font-size:18px;
}
.expiration-date{
    position: absolute;
    left: 50px;
    width: 1000px;
    font-size:18px;
     margin-top: 3px;
}
/* QR Code positioned EXACTLY over QR box */

.qr {
    position: absolute;
    top: 808px;
    right: 270px;
    width: 120px;
    height: 120px;
}
.qr img{
    width:100%;
    height:100%;
}
</style>
</head>

<body>

<?php if (!$show_prompt && (!isset($_GET['download']) || $_GET['download'] !== '1')): ?>
<button class="download-btn" id="downloadBtn" onclick="downloadPDF()">
    <i class="mdi mdi-download"></i> Download as PDF
</button>
<?php
endif; ?>

<div class="certificate">

    <!-- Dynamic Name -->
    <div class="name">
        <?php echo strtoupper($name); ?>
    </div>

    <!-- Certificate Details -->
    <div class="details">
        <div class="issue-date"><strong><?php echo $issued; ?></strong></div>
        <div class="validity-period"><strong><?php echo $validity_period; ?></strong></div>
        <div class="cert-code-box"><strong>
        <?php echo $certificate_code; ?></strong></div>
         <div class="expiration-date"><strong><?php echo $expiration_date; ?></strong></div>
    </div>

    

    <!-- QR inside QR BOX -->
    <div class="qr" <?php if (!$qr_code): ?>style="display:none;"<?php
endif; ?>>
        <img src="<?php echo $qr_code; ?>">
    </div>

</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    <?php if ($show_prompt): ?>
    Swal.fire({
        title: 'Enter Certificate Code',
        text: 'Please enter the certificate code to view the certificate.',
        input: 'text',
        inputPlaceholder: 'e.g. AGISL/EHS/...',
        showCancelButton: false,
        confirmButtonText: 'View Certificate',
        confirmButtonColor: '#007bff',
        allowOutsideClick: false,
        allowEscapeKey: false,
        inputValidator: (value) => {
            if (!value) {
                return 'You need to enter a certificate code!'
            }
        }
    }).then((result) => {
        if (result.isConfirmed) {
            const code = result.value;
            fetch('/backend/backend.php?action=set_cert_session&code=' + encodeURIComponent(code))
                .then(response => response.json())
                .then(data => {
                    if (data.status === 'success') {
                        window.location.href = '?code=' + data.encrypted_code;
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: data.message || 'Invalid certificate code.',
                            confirmButtonColor: '#dc3545'
                        }).then(() => {
                            window.location.reload();
                        });
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    window.location.reload();
                });
        }
    });
    <?php
endif; ?>
    <?php if (isset($bg_image_missing) && $bg_image_missing): ?>
    Swal.fire({
        icon: 'warning',
        title: 'Certificate Type Not Found',
        text: 'The specific background image for this certificate type ("<?php echo $cert_type; ?>") was not found. Returning to previous page.',
        confirmButtonColor: '#007bff'
    }).then(() => {
        window.history.back();
    });
    <?php
endif; ?>

    // Auto-trigger download if 'download=1' is in URL
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('download') === '1') {
        setTimeout(downloadPDF, 1500); // Small delay to ensure everything is loaded (QR, etc)
    }
});

function downloadPDF() {
    const element = document.querySelector('.certificate');
    const downloadBtn = document.getElementById('downloadBtn');
    
    // Hide button during capture
    if (downloadBtn) downloadBtn.classList.add('download-btn-hidden');

    const opt = {
        margin: 0,
        filename: 'Certificate_<?php echo addslashes($name); ?>_<?php echo $certificate_code; ?>.pdf',
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { 
            scale: 2, 
            useCORS: true,
            logging: false,
            letterRendering: true
        },
        jsPDF: { unit: 'px', format: [1400, 990], orientation: 'landscape' }
    };

    // New Promise-based usage:
    html2pdf().set(opt).from(element).save().then(() => {
        // Restore button after capture
        if (downloadBtn) downloadBtn.classList.remove('download-btn-hidden');
    }).catch(err => {
        console.error('PDF Generation Error:', err);
        if (downloadBtn) downloadBtn.classList.remove('download-btn-hidden');
    });
}
</script>

</body>
</html>
